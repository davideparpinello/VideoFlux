# Roadmap of ComNetsEmu #

**Warning**: This is not a commitment but plan of work. This list is obviously neither complete nor guaranteed.

*   Version 0.1.8, 0.1.9, 0.2.0:

    -  Expose VNF manager APIs to DockerHost for practical cluster emulation.
    -  Add an basic usage example of practical packet generator (possible candidates: Flent, Trex or MoonGen) for network latency benchmark.
    -  Add basic internal container migration APIs.
    -  Refactor current CLI implementation.
