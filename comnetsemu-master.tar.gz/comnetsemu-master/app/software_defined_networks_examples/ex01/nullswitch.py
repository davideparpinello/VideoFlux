from mininet.node import Switch

class NullSwitch(Switch):
    def start(self, controllers):
        pass

