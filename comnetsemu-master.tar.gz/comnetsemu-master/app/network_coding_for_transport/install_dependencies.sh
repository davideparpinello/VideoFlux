#!/usr/bin/env bash

pip3 install numpy scipy
