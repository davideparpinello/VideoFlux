#!/bin/bash

docker build --rm -t flowvisor:latest -f ./Dockerfile.flowvisor .
