#!/bin/sh
#BROKER
mosquitto -v -p 1883:1883
