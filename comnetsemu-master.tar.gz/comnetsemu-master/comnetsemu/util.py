#! /usr/bin/env python3
# -*- coding: utf-8 -*-

"""
About: Utilities/Helpers for ComNetsEmu.
       Should be used in ComNetsEmu's Python modules
"""
